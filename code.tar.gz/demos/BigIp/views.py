from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from .functions import *

# Create your views here.
@csrf_exempt
def test_view(request):
        
        datos_body = json.loads(request.body.decode("utf-8"))

        board_id = datos_body["payload"]["inboundFieldValues"]["boardId"]
        item_id = datos_body["payload"]["inboundFieldValues"]["itemId"]

        apiToken = "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjAyMzA5MywiYWFpIjoxMSwidWlkIjo2ODQwNzM4MCwiaWFkIjoiMjAyNC0xMS0yN1QxNjowMzoxMi4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6MjY0MzQxODcsInJnbiI6ImV1YzEifQ.yLuTp99bi-USR0zNNZowT0LIh9ncT4W-9zD0vBup19Y"

        create_item_test = create_item(apiToken)
        print(f"esto es create item {create_item_test}")

        return JsonResponse({'funciona': 'funciona'})