import requests
import datetime
import time
from dateutil.relativedelta import relativedelta


def monday_request(query,short_lived_token):
    # create_an_update(short_lived_token,"Entro en monday_request")
    

    apiUrl = "https://api.monday.com/v2"
    headers = {"Authorization" : short_lived_token, "API-Version" : "2023-10"}
    data = {"query" : query}
    #print(f"query en monday_request = {query}")
    r = requests.post(url=apiUrl, json=data, headers=headers)
    print(f"r en monday_request = {r.text}")

    # print(f"resultado consulta en monday_request = {r.json()}")
    if "errors" in r.json():
        try:
            print(f"entro en error_code")
            # int(error_message.split()[-2]) + 1
            if r.json()["error_code"] == 'ComplexityException':
                print(f"entro en complexity error")
                seconds_to_wait = int(r.json()["errors"][0].split()[-2])+1
                print(f"Complexity budget exhausted, waiting {seconds_to_wait}seg")
                
                time.sleep(seconds_to_wait+1)
                # print(f"query en return Complexity budget exhausted = {query}")
                return monday_request(query,short_lived_token)
            else:
                print(f"ERROR EN MONDAY REQUEST = {r.json()}")
                return f"ERROR{r.json()}"
            
            
        except:
            print(f"ERROR EN MONDAY REQUEST = {r.json()}")
            return f"ERROR{r.json()}"
    # print(f"r.json() despues condiciones errores= {r.json()}")
    
    return r.json()

def create_item( apiToken):
    mutation = '''mutation {
  create_item (board_id: 1722056941, item_name: "item test created", column_values: "{\"date\":\"2023-05-25\"}") {
    id
  }
}

'''
    request = monday_request(mutation, apiToken)
    return request